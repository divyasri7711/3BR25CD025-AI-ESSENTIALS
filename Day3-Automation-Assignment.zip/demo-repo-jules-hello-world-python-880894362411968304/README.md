# Hello World

A minimal Python Hello World project.

## How to Run

To run the program, ensure you have Python 3 installed and execute:

```bash
python3 hello.py
```
